from django.shortcuts import render, HttpResponse, redirect
from .models import Clothing
from django.core.urlresolvers import reverse

def index(request):
    response = "Hello, I am your first request!"
    all_items = Clothing.objects.all()
    content = {
        'all_items': all_items
    }
    return render(request, 'buy/index.html', content)

def buy(request):
    product_id = int(request.POST['product_id'])
    a = Clothing.objects.get(id=product_id)
    request.session['item_cost'] = a.price * int(request.POST['quantity'])
    if 'total_spent' in request.session:
        request.session['total_spent'] += request.session['item_cost']
    else:
        request.session['total_spent'] = request.session['item_cost']
    if 'total_items' in request.session:
        request.session['total_items'] += int(request.POST['quantity'])
    else:
        request.session['total_items'] = int(request.POST['quantity'])
    return redirect(reverse('my_checkout'))

def checkout(request):
    return render(request, 'buy/checkout.html')