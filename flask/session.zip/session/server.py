from flask import Flask, render_template, redirect, session, request
app = Flask(__name__)
app.secret_key = 'ThisIsSecret'
@app.route('/')
def index():
    if 'count' in session:
        print('name exists')
        session['count'] += 1
    else:
        session['count'] = 1
        print('name doesn\'t exist')
    return render_template("index.html")
@app.route('/destroy_session')
def delete():
    session.clear()
    return redirect('/')
@app.route('/add_two')
def adding():
    session['count'] += 1
    return redirect('/')
if __name__ == "__main__":
    app.run(debug=True)
