import random
from flask import Flask, render_template, redirect, session, request, Markup
app = Flask(__name__)
app.secret_key="hello"
@app.route('/')
def index():
    if 'correct_num' in session:
        if session['guessed_num'] > session['correct_num']:
            print("greater_than")
            return render_template("index.html", box_size = "200px", text="Too high!", color="red", attribute="hidden")
        elif session['guessed_num'] < session['correct_num']:
            print("less_than")
            return render_template("index.html", box_size = "200px", text="Too low!", color="red", input_val="", attribute="hidden")
        else:
            textstr = str(session['guessed_num']) + " was the number!"
            return render_template("index.html", box_size = "200px", color="green", text=textstr, attribute="visible")
    else:
        session['correct_num'] = random.randrange(0,101)
        print(session['correct_num'])
        return render_template("index.html", box_size = 0, color="red", attribute="hidden")
@app.route('/guess', methods=["POST"])
def guess():
    print('went through')
    session['guessed_num'] = int(request.form['number'])
    return redirect('/')
@app.route('/clearboard')
def clear():
    session.clear()
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)
