from flask import Flask, render_template
app = Flask(__name__)
@app.route('/')
def first():
	return "welcome"
@app.route('/play')
def index():
    return render_template("index.html", num=3, boxcolor='lightblue')

@app.route('/play/<x>')
def repeat_box(x):
	return render_template("index.html", num = int(x), boxcolor = 'lightblue')

@app.route('/play/<x>/<color>')
def different_boxes(x, color):
	return render_template("index.html", num = int(x), boxcolor = color)

if __name__=="__main__":
    app.run(debug=True)
