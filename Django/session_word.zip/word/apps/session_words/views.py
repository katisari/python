from django.shortcuts import render, HttpResponse, redirect
from time import gmtime, strftime
from django.contrib import messages

def index(request):
    return render(request, 'session_words/index.html')

def add_word(request):

    if 'words' not in request.session:
        request.session['words'] = []
    
    temp_list = request.session['words']
    temp_list.append({"word": request.POST['word'], "color": request.POST['color'], 
    "show_big": request.POST['big_font'], "time": strftime("%H:%M %p %b %d, %Y", gmtime())})
    request.session['words'] = temp_list     
    return redirect('/session_words')

def clear(request):
    request.session.flush()
    return redirect('/session_words')