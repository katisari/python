from django.shortcuts import render, HttpResponse, redirect
import random
from time import gmtime, strftime

def index(request):
    if 'total_gold' not in request.session:
        request.session['total_gold'] = 0
        request.session['activity'] = []
    return render(request, 'first_page/index.html')

def process(request):
    if request.POST['building'] == 'farm':
        money = random.randrange(10,20)
    elif request.POST['building']== 'cave':
        money = random.randrange(5,10)
    elif request.POST['building']== 'house':
        money = random.randrange(2,5)
    elif request.POST['building']== 'casino':
        money = random.randrange(-50,50)
    request.session['total_gold'] += money
    time = strftime("%Y/%m/%d %H:%M %p", gmtime())
    temp_list = request.session['activity']
    if money >= 0:
        content = "Earned " + str(money) + " golds from the " + request.POST['building'] + "! (" + str(time) + ")"
        color = "green"
    else:
        content = "Entered a casino and lost " + str(money) + " golds... Ouch (" + str(time) + ")"
        color = "red"
    temp_list.append({"content": content, "color": color})
    request.session['activity'] = temp_list
    return redirect('/')
    