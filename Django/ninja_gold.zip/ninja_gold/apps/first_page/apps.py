from django.apps import AppConfig


class FirstPageConfig(AppConfig):
    name = 'first_page'
