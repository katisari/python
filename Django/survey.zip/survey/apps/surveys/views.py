from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages

def index(request):
    return render(request, 'surveys/index.html')

def process(request):
    if request.method == 'POST':
        data = {
            'Name': request.POST['name'],
            'Location': request.POST['location'],
            'Favorite language': request.POST['language'],
            'Comment': request.POST['comment']
        }
        request.session['saved_info'] = data
        if 'num_submitted' in request.session:
            request.session['num_submitted'] += 1
        else:
            request.session['num_submitted'] = 1
    messages.success(request, 'Thanks for submitting this form! You have submitted this form ' +
    str(request.session['num_submitted']) + '   times now.')
    return redirect('/result')

def result(request):
    return render(request, 'surveys/result.html')

