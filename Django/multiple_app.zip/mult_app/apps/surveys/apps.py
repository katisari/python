from django.apps import AppConfig


class SurveysConfig(AppConfig):
    name = 'surveys'
