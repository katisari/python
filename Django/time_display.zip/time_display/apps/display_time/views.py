from django.shortcuts import redirect, HttpResponse, render
from time import gmtime, strftime

def index(request):
    context = {
        "date": strftime("%b %d,%Y", gmtime()),
        "time": strftime("%H:%M %p", gmtime())
    }
    print("**********",context['time'])
    return render(request, 'display_time/index.html', context)