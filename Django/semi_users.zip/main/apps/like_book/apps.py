from django.apps import AppConfig


class LikeBookConfig(AppConfig):
    name = 'like_book'
