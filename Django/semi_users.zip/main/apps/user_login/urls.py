from django.conf.urls import url
from . import views           
urlpatterns = [
    url(r'^users$', views.index, name="front_page"),
    url(r'^users/(?P<number>\d+)$', views.show, name="show"),
    url(r'^users/(?P<number>\d+)/edit$', views.edit, name="my_edit"),
    url(r'^users/(?P<number>\d+)/update$', views.update, name="update_page"),
    url(r'^users/new$', views.new, name='my_new'),
    url(r'^users/create$', views.create, name='process'),
    url(r'^users/(?P<number>\d+)/destroy$', views.delete, name="my_delete")
]                            
