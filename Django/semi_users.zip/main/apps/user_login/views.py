from django.shortcuts import render, HttpResponse, redirect
from .models import *
from django.core.urlresolvers import reverse
from django.contrib import messages

  # the index function is called when root is visited
def index(request):
    content = {
        'all_users': User.objects.all()
    }
    return render(request, 'user_login/index.html', content)

def show(request, number):
    content = {
        'user_info': User.objects.get(id=number)
    }
    return render(request, 'user_login/show.html', content)

def edit(request, number):
    content = {
        'user_info': User.objects.get(id=number)
    }
    return render(request, 'user_login/edit.html', content)

def update(request, number):
    if request.method == "POST":
        if len(request.POST['first_name']) < 1:
            messages.error(request, "User's first name should not be empty")
        if len(request.POST['last_name']) < 1:
            messages.error(request, "User's last name should not be empty")
        if len(request.POST['email']) < 1:
            messages.error(request, "User's email should not be empty")
        user_info = User.objects.get(id=number)
        user_info.first_name = request.POST['first_name']
        user_info.last_name = request.POST['last_name']
        user_info.email = request.POST['email']
        user_info.save()
        messages.success(request, "User successfullly updated")
            
        return redirect(reverse('my_edit', kwargs={'number': user_info.id}))

def new(request):
    return render(request, 'user_login/new.html')

def create(request):
    if request.method == "POST":
        User.objects.create(first_name=request.POST['first_name'], last_name=request.POST['last_name'], email_address=request.POST['email'], age=15)
        return redirect(reverse('front_page'))
    return redirect(reverse('my_new'))

def delete(request, number):
    b = User.objects.get(id=number)
    b.delete()
    # messages.success(request, "User has been deleted")
    return redirect(reverse('front_page'))

