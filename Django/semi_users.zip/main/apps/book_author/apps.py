from django.apps import AppConfig


class BookAuthorConfig(AppConfig):
    name = 'book_author'
