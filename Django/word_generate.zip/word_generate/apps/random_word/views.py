from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string

def index(request):
    unique_word = get_random_string(length=14)
    context = {
        'unique_word': unique_word
    }
    if 'attempt' not in request.session:
        request.session['attempt'] = 1
    return render(request, 'random_word/index.html', context)

def create(request):
    if request.method == "POST":
        print(request.POST)
        request.session['attempt']+=1
        print(request.session['attempt'])
    return redirect('/random_word')

def reset(request):
    request.session.flush()
    return redirect('/random_word')
