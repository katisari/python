from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^$', views.index), 
    url(r'^register$', views.register, name="register"),
    url(r'^wall$', views.wall, name="wall"), 
    url(r'^login$', views.login, name="login"),
    url(r'^wall/post_message$', views.post_message, name="post_message"),
    url(r'^wall/post_comment$', views.post_comment, name="post_comment"),
    url(r'^wall/delete_msg$', views.delete_msg, name="delete_msg"),
    url(r'^logoff$', views.logoff)
]