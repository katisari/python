from django.apps import AppConfig


class WallerConfig(AppConfig):
    name = 'waller'
