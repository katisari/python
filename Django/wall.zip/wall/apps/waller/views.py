from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from django.core.urlresolvers import reverse
import re, bcrypt
from django.contrib.messages import get_messages
from .models import *

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')


def index(request):
    return render(request, 'waller/index.html')

def register(request):
    if len(request.POST['first_name']) < 2 or (not request.POST['first_name'].isalpha()):
        messages.error(request, 'Enter correct first name.')
    if len(request.POST['last_name']) < 2 or (not request.POST['first_name'].isalpha()):
        messages.error(request, 'Enter correct last name.')
    if not EMAIL_REGEX.match(request.POST['email']):
        messages.error(request, 'Email cannot be blank!')
    try:
        match = User.objects.get(email=request.POST['email'])
        messages.error(request, 'Email already taken')
    except:
        print("yes")
    if len(request.POST['password']) < 8:
        messages.error(request, ' No fewer than 8 characters in password length')
    if request.POST['password'] != request.POST['confirm_pw']:
        messages.error(request, 'Passwords do not match.')
    message_received = get_messages(request)
    if message_received:
        return redirect('/')
    password = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())
    b=User.objects.create(first_name= request.POST['first_name'], last_name=request.POST['last_name'], email=request.POST['email'], password=password)
    request.session['logged_name'] = b.first_name
    request.session['user_id'] = b.id
    messages.success(request, 'User Created')
    return redirect(reverse('wall'))

def login(request):
    if len(request.POST['email']) < 1 or len(request.POST['password'])< 1:
        messages.error(request, 'Please fill in all fields.')
        return redirect('/')
    try:
        user_info = User.objects.get(email=request.POST['email'])
    except:
        print("yes")
        messages.error(request, 'Invalid login')
        return redirect('/')
    if not bcrypt.checkpw(request.POST['password'].encode(), user_info.password.encode()):
        messages.error(request, 'Invalid login')
        return redirect('/')
    else:
        request.session['logged_name'] = user_info.first_name
        request.session['user_id'] = user_info.id
        return redirect(reverse('wall')) 

def wall(request):
    content = {
        "all_msg": Message.objects.all(),
        "all_comments": Comment.objects.all() 
    }
    return render(request, 'waller/wall.html', content)

def post_message(request):
    b = User.objects.get(id=request.session['user_id'])
    Message.objects.create(content=request.POST['msg_content'], user=b)
    return redirect(reverse('wall'))
    # b = User.objects.

def post_comment(request):
    b = Message.objects.get(id=int(request.POST['msg_id']))
    a = User.objects.get(id=request.session['user_id'])
    Comment.objects.create(comment=request.POST['comment_content'], message= b, user=a)
    return redirect(reverse('wall'))

def delete_msg(request):
    deleting_msg = Message.objects.get(id=int(request.POST['msg_id']))
    all_comments = Comment.objects.filter(message= deleting_msg)
    for i in all_comments:
        i.delete()
    deleting_msg.delete()
    return redirect(reverse('wall'))

def logoff(request):
    request.session.flush()
    return redirect('/')